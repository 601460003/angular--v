import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pinfo',
  templateUrl: './pinfo.component.html',
  styleUrls: ['./pinfo.component.scss']
})
export class PinfoComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
