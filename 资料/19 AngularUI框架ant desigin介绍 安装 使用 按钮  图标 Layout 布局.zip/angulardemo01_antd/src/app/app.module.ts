import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppComponent } from './app.component';

/*
1.安装
npm install ng-zorro-antd --save

2.引入
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

3.注入

 NgZorroAntdModule.forRoot()   //注入antd

 BrowserAnimationsModule

*/

//引入antd
import { NgZorroAntdModule } from 'ng-zorro-antd';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    NgZorroAntdModule.forRoot()   //注入antd
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
