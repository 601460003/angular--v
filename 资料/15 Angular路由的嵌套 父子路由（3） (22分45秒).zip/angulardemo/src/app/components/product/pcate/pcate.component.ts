import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pcate',
  templateUrl: './pcate.component.html',
  styleUrls: ['./pcate.component.scss']
})
export class PcateComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
